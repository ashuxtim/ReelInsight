import { useState } from 'react';
import axios from 'axios';
import { Search, Play, Loader2, X, Clock, Video, MessageSquare, FileText, Send } from 'lucide-react';

const API_URL = "http://127.0.0.1:8000";

function App() {
  const [activeTab, setActiveTab] = useState("search"); // 'search' | 'chat' | 'summary'
  
  // Search State
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeVideo, setActiveVideo] = useState(null);

  // Chat State
  const [chatQuery, setChatQuery] = useState("");
  const [chatResponse, setChatResponse] = useState(null);
  const [chatLoading, setChatLoading] = useState(false);

  // Summary State
  const [summary, setSummary] = useState(null);
  const [summaryLoading, setSummaryLoading] = useState(false);
  // Hardcoded for now, or fetch from /videos endpoint
  const [selectedVideoFilter, setSelectedVideoFilter] = useState(""); 

  // --- HELPERS ---
  const getImageUrl = (localPath) => {
    if (!localPath) return "";
    const relative = localPath.split("data")[1]; 
    return `${API_URL}/data${relative.replace(/\\/g, "/")}`;
  };

  const getVideoUrl = (vidId, timestamp) => {
    return `${API_URL}/data/raw_videos/${vidId}.mp4#t=${timestamp}`;
  }

  // --- HANDLERS ---
  const handleSearch = async () => {
    if (!query) return;
    setLoading(true);
    try {
      const res = await axios.get(`${API_URL}/search`, { params: { query, k: 12 } });
      setResults(res.data.results);
    } catch (err) { alert("Backend Error!"); }
    setLoading(false);
  };

  const handleChat = async () => {
    if (!chatQuery) return;
    setChatLoading(true);
    setChatResponse(null);
    try {
      const res = await axios.get(`${API_URL}/ask_ai`, { 
        params: { query: chatQuery, video_filter: selectedVideoFilter || null } 
      });
      setChatResponse(res.data);
    } catch (err) { alert("Backend Error!"); }
    setChatLoading(false);
  };

  const handleSummary = async () => {
    // For demo, we just pick the first result's video ID if filter is empty, 
    // or you can implement a dropdown to select videos.
    const targetVideo = selectedVideoFilter || (results[0]?.video_id);
    
    if (!targetVideo) {
      alert("Please search for a video first or select one!");
      return;
    }

    setSummaryLoading(true);
    try {
      const res = await axios.get(`${API_URL}/summarize`, { params: { video_id: targetVideo } });
      setSummary(res.data.summary);
    } catch (err) { alert("Backend Error!"); }
    setSummaryLoading(false);
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-indigo-500 selection:text-white pb-20">
      
      {/* --- HEADER --- */}
      <div className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40 backdrop-blur-md bg-opacity-80">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Video className="text-indigo-500" />
            <h1 className="text-xl font-bold bg-gradient-to-r from-indigo-400 to-cyan-400 bg-clip-text text-transparent">
              ReelInsight
            </h1>
          </div>
          
          {/* Navigation Tabs */}
          <div className="flex bg-slate-800/50 rounded-lg p-1">
            <button 
              onClick={() => setActiveTab("search")}
              className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${activeTab === 'search' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-white'}`}
            >
              <Search size={16} /> Search
            </button>
            <button 
              onClick={() => setActiveTab("chat")}
              className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${activeTab === 'chat' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-white'}`}
            >
              <MessageSquare size={16} /> Chat
            </button>
            <button 
              onClick={() => setActiveTab("summary")}
              className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${activeTab === 'summary' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-white'}`}
            >
              <FileText size={16} /> Summary
            </button>
          </div>
        </div>
      </div>

      {/* --- CONTENT AREA --- */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        
        {/* === SEARCH TAB === */}
        {activeTab === 'search' && (
          <div className="animate-in fade-in duration-300">
             {/* Search Input */}
             <div className="relative max-w-2xl mx-auto mb-12">
              <input
                type="text"
                className="w-full bg-slate-900 border border-slate-700 rounded-full py-4 px-6 pl-12 text-lg focus:outline-none focus:border-indigo-500 transition-all shadow-xl"
                placeholder="Search visual moments or spoken words..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
              <Search className="absolute left-4 top-4.5 text-slate-500" size={24} />
              <button 
                onClick={handleSearch}
                disabled={loading}
                className="absolute right-2 top-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-full font-medium transition-colors"
              >
                {loading ? <Loader2 className="animate-spin" /> : "Search"}
              </button>
            </div>

            {/* Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {results.map((r, idx) => (
                <div 
                  key={idx} 
                  className="group bg-slate-900 rounded-xl border border-slate-800 overflow-hidden cursor-pointer hover:border-indigo-500/50 transition-all"
                  onClick={() => setActiveVideo(r)}
                >
                  <div className="relative aspect-video bg-black">
                    <img src={getImageUrl(r.frame_path)} className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity"/>
                    <div className="absolute top-2 left-2">
                      <span className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase ${r.type.includes('Visual') ? 'bg-purple-600' : 'bg-emerald-600'}`}>
                        {r.type}
                      </span>
                    </div>
                    <div className="absolute bottom-2 right-2 bg-black/80 px-2 py-1 rounded text-xs text-white font-mono">
                      {Math.floor(r.timestamp)}s
                    </div>
                  </div>
                  <div className="p-4">
                    <p className="text-xs text-slate-400 line-clamp-2">"{r.context.replace('Said:', '').trim()}"</p>
                    <div className="mt-2 flex items-center gap-2">
                       <div className="h-1 flex-1 bg-slate-800 rounded-full"><div className="h-full bg-indigo-500 rounded-full" style={{width: `${r.score*100}%`}}></div></div>
                       <span className="text-[10px] text-slate-500">{(r.score*100).toFixed(0)}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* === CHAT TAB === */}
        {activeTab === 'chat' && (
           <div className="max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-300">
             <div className="bg-slate-900 rounded-2xl border border-slate-800 p-8 shadow-2xl">
               <div className="text-center mb-8">
                 <div className="w-16 h-16 bg-indigo-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                   <MessageSquare className="text-indigo-400" size={32} />
                 </div>
                 <h2 className="text-2xl font-bold text-white">Ask the Video</h2>
                 <p className="text-slate-400">Ask questions about specific details, events, or dialogue.</p>
               </div>

               {/* Chat Input */}
               <div className="flex gap-4 mb-8">
                 <input 
                   type="text" 
                   className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 focus:outline-none focus:border-indigo-500"
                   placeholder="e.g. What color was the car? or Who is speaking?"
                   value={chatQuery}
                   onChange={(e) => setChatQuery(e.target.value)}
                   onKeyDown={(e) => e.key === 'Enter' && handleChat()}
                 />
                 <button 
                   onClick={handleChat}
                   disabled={chatLoading}
                   className="bg-indigo-600 hover:bg-indigo-700 px-6 rounded-xl font-medium transition-colors"
                 >
                   {chatLoading ? <Loader2 className="animate-spin" /> : <Send size={20} />}
                 </button>
               </div>

               {/* Response Area */}
               {chatResponse && (
                 <div className="bg-slate-950 rounded-xl p-6 border border-slate-800">
                   <h3 className="text-indigo-400 font-semibold mb-2">AI Answer:</h3>
                   <p className="text-slate-200 leading-relaxed">{chatResponse.answer}</p>
                   
                   <div className="mt-4 pt-4 border-t border-slate-800">
                     <h4 className="text-xs font-bold text-slate-500 uppercase mb-2">Evidence Sources</h4>
                     <div className="flex flex-wrap gap-2">
                       {chatResponse.context.map((ctx, i) => (
                         <span key={i} className="text-xs bg-slate-900 border border-slate-700 px-2 py-1 rounded text-slate-400 cursor-pointer hover:border-indigo-500 hover:text-indigo-400 transition-colors"
                               onClick={() => setActiveVideo(ctx)}>
                           at {Math.floor(ctx.timestamp)}s
                         </span>
                       ))}
                     </div>
                   </div>
                 </div>
               )}
             </div>
           </div>
        )}

        {/* === SUMMARY TAB === */}
        {activeTab === 'summary' && (
          <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-300">
             <div className="bg-slate-900 rounded-2xl border border-slate-800 p-8">
               <div className="flex items-center justify-between mb-8">
                 <div>
                    <h2 className="text-2xl font-bold text-white">Video Summary</h2>
                    <p className="text-slate-400 text-sm mt-1">
                      {results[0] ? `Analyzing: ${results[0].video_id}` : "Select a video via search first"}
                    </p>
                 </div>
                 <button 
                   onClick={handleSummary}
                   disabled={summaryLoading}
                   className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2 rounded-lg font-medium flex items-center gap-2 transition-colors"
                 >
                   {summaryLoading ? <Loader2 className="animate-spin" size={18}/> : "Generate Summary"}
                 </button>
               </div>

               {summary ? (
                 <div className="prose prose-invert max-w-none">
                    <div className="bg-slate-950 p-8 rounded-xl border border-slate-800 leading-relaxed whitespace-pre-wrap">
                      {summary}
                    </div>
                 </div>
               ) : (
                 <div className="text-center py-20 border-2 border-dashed border-slate-800 rounded-xl">
                   <FileText className="mx-auto text-slate-700 mb-4" size={48} />
                   <p className="text-slate-500">Click generate to analyze the transcript.</p>
                 </div>
               )}
             </div>
          </div>
        )}

      </div>

      {/* --- VIDEO MODAL (Shared) --- */}
      {activeVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-sm p-4" onClick={() => setActiveVideo(null)}>
          <div className="bg-slate-900 w-full max-w-5xl rounded-2xl overflow-hidden border border-slate-700 shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="relative aspect-video bg-black">
              <video controls autoPlay className="w-full h-full" src={getVideoUrl(activeVideo.video_id, activeVideo.timestamp)} />
            </div>
            <div className="p-4 flex justify-between items-center">
               <h3 className="text-white font-medium">Playing at {Math.floor(activeVideo.timestamp)}s</h3>
               <button onClick={() => setActiveVideo(null)} className="text-slate-400 hover:text-white"><X /></button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;